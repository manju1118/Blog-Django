from django.contrib import admin
from blog_app.models import *



class PostModelAdmin(admin.ModelAdmin):
    list_display = ('title','date_created')


admin.site.register(Post,PostModelAdmin)
admin.site.register(Comment)