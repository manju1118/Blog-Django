from django import forms
from . models import *


class PostModelForm(forms.ModelForm):
    content = forms.CharField(widget=forms.Textarea(attrs={'rows': 2}))
    class Meta:
        model = Post
        fields = ('title','content')

class post_update_form(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title','content')

class comments_form(forms.ModelForm):
    content = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder':'Add comment here...'}))
    class Meta:
        model = Comment
        fields = ('content',)
        