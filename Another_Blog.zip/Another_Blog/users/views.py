from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import SignUpForm,user_update_form,profile_update_form

from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required



def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignUpForm()
    context = {
        'form':form
    }
    return render(request,'users/signup.html',context)

@login_required
def user_logout(request):
    logout(request)
    return redirect('index')

@login_required
def user_profile(request):
    if request.method == 'POST':
        u_form  = user_update_form(request.POST or None, instance=request.user)
        p_form = profile_update_form(request.POST or None, request.FILES or None,instance=request.user.profilemodel)

        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            return redirect('user_profile')
    else:
        u_form = user_update_form(instance=request.user)
        p_form = profile_update_form(instance=request.user.profilemodel)
    context = {
        'u_form':u_form,
        'p_form':p_form
    }
    return render(request,'users/profile.html',context)